# حالة التسليم — إعلاني | E3lani

**تاريخ التحديث:** 27 يوليو 2026  
**الفرع:** `cursor/phase-1-foundation-b0e4`  
**PR:** #2 (Draft)  
**الحالة العامة:** Phase 3 — واجهات مربوطة بالـAPI الحقيقي ومسار مستخدم كامل في Sandbox. **ليست جاهزة لتحصيل أموال حقيقية أو الإطلاق الإنتاجي.**

## ما تم في Phase 3

- ربط Web / Admin / Expo بالـAPI الحقيقي عبر `@e3lani/api-client`
- إزالة Demo/Mock من المسارات الأساسية
- مسار كامل: OTP → إنشاء → رفع وسائط → مراجعة → دفع بعد القبول → Webhook → Feed
- واجهات: تصفح، أقسام، إنشاء، حالة، دفع، حساب، محفوظات، إعلان، براند، مراجعة إدارة، مدفوعات
- فيديو حقيقي (FFmpeg + MinIO) مع حالات المعالجة
- Playwright E2E + اختبار دخان للجوال عبر API

## التسعير المعتمد (لم يُغيَّر)

| الخدمة | السعر |
|---|---|
| إعلان 30 يومًا | 59 ر.س |
| إعادة نشر | 10 ر.س |
| تمديد 15 يومًا | 29 ر.س |
| إبراز 3/7 أيام | 15 / 29 ر.س |
| أعلى القسم | 29 ر.س |
| مدينة إضافية | 10 ر.س |

## نتائج التحقق (Phase 3)

- `pnpm typecheck` / `lint` / `test` / `build` — ناجح
- `pnpm test:integration` — `PHASE2_INTEGRATION_OK`
- `pnpm test:e2e` — ناجح (مسار فيديو كامل + دخان جوال)
- لقطات المسار: `/opt/cursor/artifacts/01` … `09`

## المتبقي قبل Production

1. StoreKit / Google Play Billing adapters مع تحقق خادمي حقيقي
2. مزود إقليمي إنتاجي (Moyasar/MyFatoorah) بمفاتيح تاجر
3. MFA للإدارة وSecret Manager
4. مراقبة إنتاجية ومفاتيح من `docs/KEYS_AND_ACCOUNTS_AR.md`

انظر أيضًا: `docs/PHASE3_REPORT_AR.md` و `docs/PHASE2_REPORT_AR.md`.
